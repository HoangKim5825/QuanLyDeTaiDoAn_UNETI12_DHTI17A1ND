# Module 3 - Quản lý sinh viên & Đăng ký đề tài

Code này hiện thực **Module 3** trong Đề tài 12 (Hệ thống quản lý đề tài đồ án và
phân công giảng viên hướng dẫn - ASP.NET Core 10 MVC):

- 7.1. Quản lý sinh viên (CRUD dành cho Admin)
- 7.2. Entity `DangKyDeTai`
- 7.3. Đăng ký đề tài (kiểm tra đầy đủ điều kiện bằng EF Core/LINQ)
- 7.4. Hủy đăng ký (chỉ khi đang "Chờ duyệt")
- 7.5. Theo dõi kết quả đăng ký (+ xem GVHD hiện tại)
- 7.6. Quy tắc dữ liệu đăng ký (tách `DangKyDeTai` và `PhanCongHuongDan`)

Ngoài ra project có kèm theo các Entity/Controller **tối thiểu** của Module 1, 2, 4
(TaiKhoan, LinhVuc, GiangVien, DeTai, PhanCongHuongDan, AccountController...) chỉ
đủ để Module 3 **build và chạy thử độc lập** trong lúc chờ ghép nối với phần của
các bạn phụ trách Module khác. Khi ghép nhóm, hãy thống nhất lại DbContext,
namespace và các Controller trùng tên.

## 1. Yêu cầu môi trường

- **.NET 10 SDK** (`dotnet --list-sdks` để kiểm tra, tải tại
  https://dotnet.microsoft.com/download/dotnet/10.0 nếu chưa có)
- **SQL Server** (LocalDB đi kèm Visual Studio, hoặc SQL Server Express/Developer)
- **Visual Studio Code** + extension **C# Dev Kit** (hoặc extension `C#` của
  Anysphere/OmniSharp)
- Công cụ `dotnet-ef` (cài 1 lần):
  ```bash
  dotnet tool install --global dotnet-ef
  ```

## 2. Mở project trong VS Code

1. Giải nén thư mục `QuanLyDeTaiDoAn` ra máy.
2. Mở VS Code -> File -> Open Folder... -> chọn thư mục `QuanLyDeTaiDoAn`.
3. Khi VS Code hỏi "Required assets to build and debug are missing", chọn **Yes**
   để tự sinh cấu hình `.vscode/launch.json` và `tasks.json`.
4. Mở Terminal trong VS Code (Ctrl+`) và chạy:
   ```bash
   dotnet restore
   dotnet build
   ```

> Nếu báo lỗi không tìm thấy package `Microsoft.EntityFrameworkCore.SqlServer`
> phiên bản `10.0.0`, hãy chạy `dotnet --list-sdks` xem SDK 10 của bạn là bản
> nào rồi sửa lại số `Version` tương ứng trong file `QuanLyDeTaiDoAn.csproj`.

## 3. Cấu hình chuỗi kết nối CSDL

Mở `appsettings.json`, sửa `ConnectionStrings:DefaultConnection` cho phù hợp máy
bạn. Mặc định đang dùng LocalDB:

```json
"DefaultConnection": "Server=(localdb)\\mssqllocaldb;Database=QuanLyDeTaiDoAn_UNETI12;Trusted_Connection=True;TrustServerCertificate=True;MultipleActiveResultSets=true"
```

Nếu dùng SQL Server Express/Developer, đổi thành dạng:
```
Server=localhost\\SQLEXPRESS;Database=QuanLyDeTaiDoAn_UNETI12;Trusted_Connection=True;TrustServerCertificate=True
```

## 4. Tạo Migration và Database (Code First)

Trong Terminal, tại thư mục gốc project:

```bash
dotnet ef migrations add InitialCreate
dotnet ef database update
```

Sau khi chạy `database update`, database sẽ được tạo với các bảng tương ứng 7
Entity. **Lưu ý:** hiện `Program.cs` đang gọi `DbInitializer.Seed()` dùng
`EnsureCreated()` để tiện chạy thử ngay không cần Migration. Khi nhóm đã thống
nhất Entity và bắt đầu dùng Migration chính thức, hãy:

1. Mở `Program.cs`, đổi dòng:
   ```csharp
   DbInitializer.Seed(db);
   ```
   thành gọi `db.Database.Migrate();` trước khi seed (bỏ comment dòng
   `// db.Database.Migrate();` và xóa `EnsureCreated()` trong `DbInitializer.cs`),
   để tránh xung đột giữa `EnsureCreated()` và Migration.

## 5. Chạy chương trình

```bash
dotnet run
```

Hoặc trong VS Code: mở tab **Run and Debug** (Ctrl+Shift+D) -> bấm nút Play (▶).

Terminal sẽ in ra địa chỉ dạng `https://localhost:5001` (hoặc cổng khác) -
mở trình duyệt đến địa chỉ đó.

## 6. Tài khoản kiểm thử (dữ liệu mẫu do DbInitializer sinh ra)

| Vai trò   | Tên đăng nhập | Mật khẩu | Ghi chú                                   |
|-----------|---------------|----------|--------------------------------------------|
| Admin     | admin         | 123456   | Quản lý sinh viên                          |
| Sinh viên | sv001         | 123456   | Đã có đề tài "Đã duyệt" + GVHD             |
| Sinh viên | sv002         | 123456   | Đã có đề tài "Đã duyệt" + GVHD             |
| Sinh viên | sv003         | 123456   | Có đăng ký "Chờ duyệt"                     |
| Sinh viên | sv004         | 123456   | Có đăng ký "Chờ duyệt"                     |
| Sinh viên | sv005         | 123456   | Có đăng ký "Đã hủy", chưa có đề tài hiệu lực|
| Sinh viên | sv006         | 123456   | Trạng thái "Ngừng học" (để test từ chối)   |

## 7. Việc CẦN LÀM TIẾP (quan trọng trước khi nộp bài)

1. **Điền thông tin cá nhân**: các file do Module 3 phụ trách chính
   (`Models/SinhVien.cs`, `Models/DangKyDeTai.cs`,
   `Controllers/SinhVienController.cs`, `Controllers/DangKyDeTaiController.cs`,
   `ViewModels/*.cs`) đang có comment mẫu ở đầu file:
   ```csharp
   // Họ và tên: (Điền họ tên của bạn)
   // Mã sinh viên: (Điền mã sinh viên của bạn)
   ```
   Hãy điền đúng thông tin thật của bạn (đúng yêu cầu mục 17 đề bài) trước khi
   commit lên GitHub.

2. **Đổi tên Project/Namespace** theo đúng quy định của đề bài (mục 3.1):
   `[TênĐềTài]_UNETI[STTNhóm]_[MãLớp]`, ví dụ `QuanLyDeTaiDoAn_UNETI12_TI17A1HN`.
   Hiện code đang dùng namespace tạm là `QuanLyDeTaiDoAn` - cả nhóm cần thống
   nhất tên thật rồi Find & Replace toàn bộ `QuanLyDeTaiDoAn` trong solution.

3. **Ghép nối với Module 1/2/4**: Module 3 đã kèm theo các entity/stub tối
   thiểu để tự chạy được. Khi ghép nhóm, hãy dùng bản `TaiKhoanController`,
   `LinhVucController`, `GiangVienController`, `DeTaiController`,
   `PhanCongHuongDanController`, `ThongKeController` do các bạn phụ trách
   Module 1/2/4 xây dựng thay cho các phần stub ở đây (đặc biệt là
   `AccountController` đang lưu mật khẩu dạng plain-text - nên để bạn phụ
   trách Module 1 hoàn thiện việc mã hóa mật khẩu nếu nhóm chọn làm phần nâng cao).

4. **Bổ sung dữ liệu mẫu** cho đủ số lượng tối thiểu theo mục 15 đề bài (05
   lĩnh vực, 12 giảng viên, 20 đề tài, 30 sinh viên, 25-30 đăng ký...) -
   `DbInitializer.cs` hiện chỉ có dữ liệu mẫu nhỏ để demo nhanh.

5. Sau khi ghép Module xong, chạy `dotnet ef migrations add <TenThayDoi>` mỗi
   khi có thay đổi Entity, **không xóa** các Migration cũ.

## 8. Giải thích nhanh luồng nghiệp vụ Module 3

```
Đăng nhập (Sinh viên)
   -> Xem danh sách đề tài đang mở (DangKyDeTaiController.DanhSachDeTai)
   -> Chọn đề tài -> Xem chi tiết + số chỗ còn (DangKy GET)
   -> Gửi đăng ký (DangKy POST) -> kiểm tra 5 điều kiện bằng LINQ -> lưu "Chờ duyệt"
   -> Theo dõi kết quả (Index) -> thấy trạng thái Chờ duyệt / Đã duyệt / Từ chối
   -> Nếu còn Chờ duyệt: có thể Hủy đăng ký (Huy POST) -> chuyển "Đã hủy"
   -> Nếu Đã duyệt: sau khi Module 4 phân công GVHD, trang Index sẽ hiển thị
      tên giảng viên hướng dẫn hiện tại (đọc từ PhanCongHuongDan)
```

`SoChoCon` của đề tài **không lưu trong Database** mà luôn được tính lại bằng
LINQ (`DangKyDeTaiController.TinhSoChoConAsync`) mỗi khi cần hiển thị hoặc
kiểm tra điều kiện đăng ký - đúng yêu cầu mục 6.7 và 9.1 của đề bài.
