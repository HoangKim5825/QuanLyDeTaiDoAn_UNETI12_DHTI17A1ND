using Microsoft.EntityFrameworkCore;
using QuanLyDeTaiDoAn.Data;

var builder = WebApplication.CreateBuilder(args);

// ===== Đăng ký DbContext (SQL Server, Code First - EF Core 10) =====
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// ===== MVC =====
builder.Services.AddControllersWithViews();

// ===== Session: dùng để lưu thông tin đăng nhập (MaTaiKhoan, HoTen, VaiTro) =====
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(60);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

var app = builder.Build();

// ===== Khởi tạo DB + seed dữ liệu mẫu khi khởi động =====
// Nếu DB cũ bị lệch schema (vd đã tạo bản cũ) -> tự xóa và tạo lại rồi seed lại.
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
    var logger = scope.ServiceProvider.GetRequiredService<ILogger<Program>>();
    try
    {
        DbInitializer.Seed(db);
    }
    catch (Exception ex)
    {
        logger.LogWarning(ex, "Seed lần 1 lỗi, thử xóa và tạo lại Database...");
        try
        {
            db.ChangeTracker.Clear();
            db.Database.EnsureDeleted();
            DbInitializer.Seed(db);
        }
        catch (Exception ex2)
        {
            // Không cho app chết ngay: vẫn chạy để xem log, nhưng in rõ nguyên nhân
            logger.LogError(ex2, "Không khởi tạo được Database. Kiểm tra SQL Server/LocalDB và ConnectionStrings trong appsettings.json.");
        }
    }
}

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseSession(); // Phải đặt trước UseAuthorization và trước khi Controller dùng Session

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
